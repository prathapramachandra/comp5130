const mongoose = require('mongoose');

// Define subtask schema
const subtaskSchema = new mongoose.Schema({
    title: {
        type: String,
        required: true,
    },
    description: String,
    completed: {
        type: Boolean,
        default: false,
    }
});

// Define task schema with advanced features
const taskSchema = new mongoose.Schema({
    title: {
        type: String,
        required: true,
    },
    description: String,
    completed: {
        type: Boolean,
        default: false,
    },
    dueDate: {
        type: Date,
        required: true,
    },
    priority: {
        type: String,
        enum: ['Low', 'Medium', 'High'],
        default: 'Low',
    },
    recurring: {
        type: String,
        enum: ['None', 'Daily', 'Weekly', 'Monthly'],
        default: 'None',
    },
    subtasks: [subtaskSchema],  // Array of subtasks
    reminder: {
        type: Date,
    }
});

// Create the Task model from the schema
const Task = mongoose.model('Task', taskSchema);
module.exports = Task;
