let tasks = JSON.parse(localStorage.getItem('tasks')) || [];
const taskList = document.getElementById('task-list');

// Dark Mode Toggle
document.getElementById('dark-mode-toggle').addEventListener('change', () => {
    document.body.classList.toggle('dark-mode');
});

// Display tasks
function displayTasks() {
    taskList.innerHTML = '';
    tasks.forEach((task, index) => {
        const li = document.createElement('li');
        li.classList.add(task.priority.toLowerCase()); // Apply priority-based styling
        li.classList.add(task.category.toLowerCase()); // Apply category-based styling
        li.innerHTML = `
            <span class="${task.completed ? 'completed' : ''}">
                ${task.title} - ${task.description} [${task.category}] (Priority: ${task.priority})
            </span>
            <div class="subtasks">
                ${task.subtasks.map(subtask => `<p>${subtask.title}: ${subtask.description} [${subtask.completed ? 'Completed' : 'Incomplete'}]</p>`).join('')}
            </div>
            <button onclick="toggleCompletion(${index})">${task.completed ? 'Undo' : 'Complete'}</button>
            <button onclick="deleteTask(${index})">Delete</button>
            <button onclick="editTask(${index})">Edit</button>
        `;
        taskList.appendChild(li);
    });

    updateProgressBar();
}

// Add Task Form Submission
document.getElementById('task-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const title = document.getElementById('title').value;
    const description = document.getElementById('description').value;
    const dueDate = document.getElementById('dueDate').value;
    const priority = document.getElementById('priority').value;
    const category = document.getElementById('category').value;
    const recurring = document.getElementById('recurring').value;

    // Subtasks: Array of subtasks
    const subtasks = [];
    document.querySelectorAll('.subtask').forEach(subtaskElement => {
        const subtaskTitle = subtaskElement.querySelector('.subtask-title').value;
        const subtaskDescription = subtaskElement.querySelector('.subtask-description').value;
        subtasks.push({ title: subtaskTitle, description: subtaskDescription, completed: false });
    });

    const task = { title, description, dueDate, priority, category, recurring, subtasks, completed: false };
    tasks.push(task);
    localStorage.setItem('tasks', JSON.stringify(tasks));
    displayTasks();
});

// Function to add a subtask form dynamically
document.getElementById('add-subtask').addEventListener('click', () => {
    const subtaskContainer = document.createElement('div');
    subtaskContainer.classList.add('subtask');
    subtaskContainer.innerHTML = `
        <input type="text" class="subtask-title" placeholder="Subtask title" required>
        <textarea class="subtask-description" placeholder="Subtask description"></textarea>
        <button type="button" onclick="removeSubtask(this)">Remove Subtask</button>
    `;
    document.getElementById('subtasks-container').appendChild(subtaskContainer);
});

// Remove a subtask
function removeSubtask(button) {
    button.parentElement.remove();
}

// Function to toggle task completion
function toggleCompletion(index) {
    tasks[index].completed = !tasks[index].completed;
    localStorage.setItem('tasks', JSON.stringify(tasks));
    displayTasks();
}

// Function to delete a task
function deleteTask(index) {
    tasks.splice(index, 1);
    localStorage.setItem('tasks', JSON.stringify(tasks));
    displayTasks();
}

// Function to edit a task
function editTask(index) {
    const task = tasks[index];
    document.getElementById('title').value = task.title;
    document.getElementById('description').value = task.description;
    document.getElementById('dueDate').value = task.dueDate;
    document.getElementById('priority').value = task.priority;
    document.getElementById('category').value = task.category;
    document.getElementById('recurring').value = task.recurring;

    // Remove the task from the array and re-render
    deleteTask(index);
}

// Update Progress Bar
function updateProgressBar() {
    const progress = tasks.filter(task => task.completed).length / tasks.length * 100;
    document.querySelector('.progress').style.width = `${progress}%`;
}

// Export tasks to CSV
document.getElementById('export-tasks').addEventListener('click', () => {
    let csvContent = "data:text/csv;charset=utf-8,Title,Description,Due Date,Category,Priority,Completed\n";
    tasks.forEach(task => {
        csvContent += `${task.title},${task.description},${task.dueDate},${task.category},${task.priority},${task.completed}\n`;
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "tasks.csv");
    document.body.appendChild(link); // Required for Firefox
    link.click();
    document.body.removeChild(link);
});

// Voice Input for Task Title
document.getElementById('voice-input').addEventListener('click', () => {
    const recognition = new window.webkitSpeechRecognition();
    recognition.lang = 'en-US';
    recognition.start();

    recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        document.getElementById('title').value = transcript; // Populate task title with voice input
    };
});

// Pomodoro Timer
let timerInterval;
document.getElementById('start-timer').addEventListener('click', () => {
    let time = 1500; // 25 minutes in seconds

    if (timerInterval) {
        clearInterval(timerInterval);
    }

    timerInterval = setInterval(() => {
        const minutes = Math.floor(time / 60);
        const seconds = time % 60;
        document.getElementById('timer').textContent = `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;

        if (time === 0) {
            clearInterval(timerInterval);
            alert('Pomodoro session finished!');
        }

        time--;
    }, 1000);
});

// Initial display of tasks
displayTasks();
